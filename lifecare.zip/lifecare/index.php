<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> Balance Life Hospital </title>

    <link rel="shortcut icon" href="images/fav.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/fontawsom-all.min.css">
     <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

    <body>

    
      <header id="menu-jk">
    
        <div id="nav-head" class="header-nav">
            <div class="container menu-1">
                <div class="row">
                    <div class="col-lg-2 col-md-3  col-sm-12" style="color:#000;font-weight:bold; font-size:42px; margin-top: 1% !important;">logo
                       <a data-toggle="collapse" data-target="#menu" href="#menu" ><i class="fas d-block d-md-none small-menu fa-bars"></i></a>
                    </div>
                    <div id="menu" class="col-lg-8 col-md-9 d-none d-md-block nav-item">
                        <ul>
                            <li><a href="#">Home</a></li>
                            <li><a href="#services">Services</a></li>
                            <li><a href="about_us\index.html">About Us</a></li>
                            <li><a href="#gallery">Gallery</a></li>
                            <li><a href="#contact_us">Contact Us</a></li>
                            <li><a href="#logins">Logins</a></li>  
                        </ul>
                    </div>
                   <div class="em_no">
                   <button type="button" class="btn btn-danger">Emergency No: 1800 2645 022</button>
                        
                   </div>
                </div>

            </div>
        </div>
    </header>
    
    <div class="slider-detail">

        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            </ol>


   


            <div class="carousel-inner">
                <div class="carousel-item ">
                    <img class="d-block w-100" src="images/slider/slider_2.jpg" alt="Second slide">
                    <div class="carousel-cover"></div>
                    <div class="carousel-caption vdg-cur d-none d-md-block">
                        <h5 class="animated bounceInDown">Balance Life Hospital</h5>
                        
                         
                    
                    </div>
                </div>
                <div class="col-sm-2 d-none d-lg-block appoint sl-1">
                        <a class="btn btn-success slider_btn" href="life/user-login.php">Book an Appointment</a>
                        </div>
                <div class="carousel-item active">
                    <img class="d-block w-100" src="images/indian-nurse1.jpg" alt="Third slide">
                      <div class="carousel-cover"></div>
                    <div class="carousel-caption vdg-cur d-none d-md-block">
                        <h5 class="animated bounceInDown">Balance Life Hospital</h5>
            
                         
                    
                    </div>
              
                </div>
                
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>

        <div class="overlay-text">
                <h2>We're here when you need us — for every care in the world.</h2>
            </div>
    </div>
    
 







    <section id="services" class="key-features department">
        <div class="container">
            <div class="inner-title">

                <h2>Significant feature</h2>
                <p>Get to know our main attributes.</p>
            </div>

            <div class="row">
                
                    <div class="col-lg-4 col-md-6">
                        <a href="feature\nurse.html">
                        <div class="single-key">
                        <i class="fa-solid fa-house-user"></i>
                        
                            <h5>Home nursing services</h5>
                        </div> 
                    </a>
                    </div>
               
                
                <div class="col-lg-4 col-md-6">
                    <a href="feature\neoro.html">
                    <div class="single-key">
                    <i class="fa-solid fa-user-doctor"></i>
                        <h5>Neurosurgeon </h5>
                    </div>
                </a>
                </div>

                <div class="col-lg-4 col-md-6">
                <a href="feature\nurse.html">
                    <div class="single-key">
                       <i class="fa-solid fa-building-columns"></i>
                        <h5>Blood & Organ Banks</h5>
                    </div>
                    </a>
                </div>

                <div class="col-lg-4 col-md-6">
                <a href="feature\bed_1.html">
                    <div class="single-key">
                    <i class="fa-solid fa-bed"></i>
                        <h5>Special Beds</h5>
                    </div>
                    </a>
                </div>

                <div class="col-lg-4 col-md-6">
                <a href="feature\nurse.html">
                    <div class="single-key">
                    <i class="fa-solid fa-globe"></i>
                        <h5>Language Assistance</h5>
                    </div>
                    </a>
                </div>



                <div class="col-lg-4 col-md-6">
                <a href="feature\nurse.html">
                    <div class="single-key">
                    <i class="fa-solid fa-droplet"></i>
                        <h5>Blood services</h5>

                    </div>
                    </a>
                </div>
            </div>






        </div>

    </section>




    <section class="about-section">
        <div class="about-container">
            <div class="about-image-wrapper">
                <img src="images/about.jpg" alt="Laptop Image" class="about-image">
            </div>
            <div class="about-text-wrapper">
                <h2 class="about-title">Get to Know Us</h2>
                <p class="about-description">
                Balance Life Hospital is designed for Any Hospital to replace their existing manual,
                 paper based system. The new system is to control the following information;
                  patient information, room availability, staff and operating room schedules,
                   and patient invoices. These services are to be provided in an efficient,
                    cost effective manner, with the goal of reducing the time and resources
                     currently required for such tasks.
                A significant part of the operation of any hospital involves the acquisition,
                 management and timely retrieval of great volumes of information. This information 
                 typically involves; patient personal information and medical history, 
                 staff information, room and ward scheduling, staff scheduling, operating theater
                  scheduling and various facilities waiting lists. All of this information must
                   be managed in an efficient and cost wise fashion so that an institution's
                    resources may be effectively utilized life will automate the management of
                     the hospital making it more efficient and error free. It aims at standardizing 
                     data, consolidating data ensuring data integrity and reducing inconsistencies.
                </p>
                <a href="about_us\index.html" class="about-button">Read More</a>
            </div>
        </div>
    </section>


    
    
 
    <section id="logins" class="our-blog container-fluid">

    <div class="card-group">
    <div class="card" style="width: 18rem;">
                <div class="imagge">
                    <img src="appointments-card.jpg" class="card-img-top" alt="doctor">
                </div>
                <div class="card-body">
                  <a class="card-title">Appointments</a>
                  <p class="card-text">Book an appointment for a seamless and stress-free healthcare experience.</p>
                  <div class="btton">
                    <a href="#" class="btn btn-primary">Schedule Now</a>
                  </div>
                </div>
              </div>
    <div class="card" style="width: 10rem;" >
                <div class="imagge">
                    <img src="doc-card.png " class="card-img-top" alt="doctor">
                </div>
                <div class="card-body">
                  <a class="card-title">Doctors Login</a>
                  <p class="card-text">Sign in to streamline your practice and enhance patient care</p>
                  <div class="btton">
                    <a href="#" class="btn btn-primary">Click Here</a>
                  </div>
                </div>
              </div>
              <div class="card" style="width: 18rem;">
                <div class="imagge">
                    <img src="locations-card.jpg" class="card-img-top" alt="doctor">
                </div>
                <div class="card-body">
                  <a class="card-title">Locations Directions</a>
                  <p class="card-text">Our hospital location is here to support your health journey</p>
                  <div class="btton">
                    <a href="#" class="btn btn-primary">Get location</a>
                  </div>
                </div>
              </div>
              
        </div>


        <div class="container">
                    
                    <div class="col-sm-4 blog-smk">
                        <div class="blog-single">

                                <img src="images/admin.jpg" alt="admin">

                            <div class="blog-single-det">
                                <h6>Admin Login</h6>
                    
                                <a href="life/admin" target="_blank">
                                    <button class="btn btn-success btn-sm">Click Here</button>
                                </a>
                            </div>
                        </div>
                    </div>   
                    
                </div>
            </div>
            
        </div>
    </section> 



        <div id="gallery" class="gallery">    
           <div class="container">
              <div class="inner-title">

                <h2>Our Gallery</h2>
                <p>View Our Gallery</p>
            </div>
              <div class="row">
                

        
        <br/>



            <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 ">
                <img src="images/gallery/gallery_5.jpg" class="img-responsive">
            </div>

            <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6">
                <img src="images/gallery/gallery_6.jpg" class="img-responsive">
            </div>

            <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 ">
                <img src="images/gallery/gallery_7.jpg" class="img-responsive">
            </div>

            <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 ">
                <img src="images/gallery/gallery_8.jpg" class="img-responsive">
            </div>

            <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 ">
                <img src="images/gallery/gallery_14.jpg" class="img-responsive">
            </div>
        
            <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6">
                <img src="images/gallery/gallery_16.jpg" class="img-responsive">
            </div>

        </div>
    </div>
       
       
       </div>
    
    <section id="contact_us" class="contact-us-single">
        <div class="row no-margin">

            <div  class="col-sm-12 cop-ck">
                <form method="post">
                <h2 >Contact Form</h2>
                    <div class="row cf-ro">
                        <div  class="col-sm-3"><label>Enter Name :</label></div>
                        <div class="col-sm-8"><input type="text" placeholder="Enter Name" name="fullname" class="form-control input-sm" required ></div>
                    </div>
                    <div  class="row cf-ro">
                        <div  class="col-sm-3"><label>Email Address :</label></div>
                        <div class="col-sm-8"><input type="text" name="emailid" placeholder="Enter Email Address" class="form-control input-sm"  required></div>
                    </div>
                     <div  class="row cf-ro">
                        <div  class="col-sm-3"><label>Mobile Number :</label></div>
                        <div class="col-sm-8"><input type="text" name="mobileno" placeholder="Enter Mobile Number" class="form-control input-sm" required ></div>
                    </div>
                     <div  class="row cf-ro">
                        <div  class="col-sm-3"><label>Enter  Message :</label></div>
                        <div class="col-sm-8">
                          <textarea rows="5" placeholder="Enter Your Message" class="form-control input-sm" name="description" required></textarea>
                        </div>
                    </div>
                     <div  class="row cf-ro">
                        <div  class="col-sm-3"><label></label></div>
                        <div class="col-sm-8">
                         <button class="btn btn-success btn-sm" type="submit" name="submit">Send Message</button>
                        </div>
                </div>
            </form>
            </div>
     
        </div>
    </section>
    

    
    
    
    

    <footer class="footer">
        <div class="container">
            <div class="row">
       
                <div class="col-md-6 col-sm-12">
                    <h2>Useful Links</h2>
                    <ul class="list-unstyled link-list">
                        <li><a ui-sref="about" href="about_us\index.html">About us</a><i class="fa fa-angle-right"></i></li>
                        <li><a ui-sref="portfolio" href="#services">Services</a><i class="fa fa-angle-right"></i></li>
                        <li><a ui-sref="products" href="#logins">Logins</a><i class="fa fa-angle-right"></i></li>
                        <li><a ui-sref="gallery" href="#gallery">Gallery</a><i class="fa fa-angle-right"></i></li>
                        <li><a ui-sref="contact" href="#contact">Contact us</a><i class="fa fa-angle-right"></i></li>
                    </ul>
                </div>
                <div class="col-md-6 col-sm-12 map-img">
                    <h2>Contact Us</h2>
                    <address class="md-margin-bottom-40">


                        R-001, Haraple Vasti, Juna Fursungi Road<br>BhekariNagar, Pune-412308 <br><br>
                        Phone: 1800 2645 022 <br>
                        Email: balancelife@lifecare.com <br>
                        Timing: 24/7<br>
                        <div class="icons">
                            <i class="fa-brands fa-instagram m-icon"></i>
                            <i class="fa-brands fa-facebook m-icon"></i>
                            <i class="fa-brands fa-x-twitter m-icon"></i>
                            <i class="fa-brands fa-threads m-icon"></i>
                        </div>
                    </address>






                </div>
            </div>
        </div>

    </footer>
    <div class="copy">
            <div class="container">
                Life Care
            </div>
    </div>
    </body>

<script src="assets/js/jquery-3.2.1.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/plugins/scroll-nav/js/jquery.easing.min.js"></script>
<script src="assets/plugins/scroll-nav/js/scrolling-nav.js"></script>
<script src="assets/plugins/scroll-fixed/jquery-scrolltofixed-min.js"></script>

<script src="assets/js/script.js"></script>



</html>